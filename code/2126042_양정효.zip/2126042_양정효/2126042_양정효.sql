-- DB Final Project Skeleton
-- Student Name: 양정효
-- Student ID: 2126042

-- 1. CREATE TABLE

CREATE TABLE class_code (
    code INT PRIMARY KEY,
    class VARCHAR(20),
    basis VARCHAR(50)
);

CREATE TABLE task_code (
    code INT PRIMARY KEY,
    task VARCHAR(50)
);

-- TODO: customer
CREATE TABLE customer(
	cus_id VARCHAR(15) PRIMARY KEY, --text book's data type is 'varchar2', but postgresql
	name VARCHAR(20) NOT NULL,		--does not exist 'varchar2'
	cell CHAR(13) NOT NULL UNIQUE,
	addr VARCHAR(100),
	c_code INTEGER DEFAULT 3 -- 'number' also doesn't exist
		CHECK(c_code IN (1,2,3)) --add check constraint
);

-- TODO: staff
CREATE TABLE staff(
	staff_id INTEGER PRIMARY KEY,
	name VARCHAR(20) NOT NULL,
	birthday INTEGER NOT NULL,
	tel CHAR(12),
	salary INTEGER,
	t_code INTEGER NOT NULL,
	hire_date CHAR(8) NOT NULL
);

-- TODO: tour
CREATE TABLE tour(
	tour_num CHAR(8) PRIMARY KEY,
	departure VARCHAR(50) NOT NULL,
	arrival VARCHAR(50) NOT NULL,
	program VARCHAR(100), 
	start_dt DATE NOT NULL,
	end_dt DATE NOT NULL,
	min_num INTEGER,
	max_num INTEGER,
	expense INTEGER NOT NULL,
	deposit INTEGER,
	dept_yn CHAR(1) DEFAULT 'N',
	staff_id INTEGER,

	FOREIGN KEY (staff_id) REFERENCES staff(staff_id)
);


-- TODO: reserve
--
CREATE TABLE reserve(
	cus_id VARCHAR(15),
	tour_num CHAR(8),
	res_date DATE DEFAULT CURRENT_TIMESTAMP, -- 교재에서는 CHAR 타입이지만, postgreSQL 기준 원활한 자료형 선정
	dep_yn CHAR(1) DEFAULT 'N',
	exp_yn CHAR(1) DEFAULT 'N',

	PRIMARY KEY (cus_id, tour_num),
	FOREIGN KEY (cus_id) REFERENCES customer(cus_id),
	FOREIGN KEY (tour_num) REFERENCES tour(tour_num)
);

-- 2. INSERT DATA

-- TODO: Insert at least 5 rows into each table
-- customer
INSERT INTO customer (cus_id, name, cell, addr, c_code) VALUES
('C001','백지헌','010-2003-0417','전남 순천',1),
('C002','최예원','010-1999-0618','부산 남구',1),
('C003','유지민','010-2000-0411','경기 성남', 1),
('C004','박시은','010-2001-0801', '서울 강남',2),
('C005','정원이','010-2004-0525','경남 거제', 3);

--staff
table staff;
INSERT INTO staff (staff_id, name, birthday, tel, salary, t_code, hire_date) values
(1, '이새롬', 19970107, '02-1997-0107',3000000,1,'20180124'),
(2, '장규리', 19971227, '02-1997-1227',3000000,2,'20180124'),
(3, '박지원', 19980320, '02-1998-0320',3000000,3,'20180124'),
(4, '배유빈', 19970909, '02-1997-0909',3600000,4, '20150420'),
(5, '김가영', 20081127, '02-2008-1127',2400000,5, '20240326');

--tour 
INSERT INTO tour (tour_num, departure, arrival, program, start_dt, end_dt, min_num, max_num, expense, deposit, dept_yn, staff_id) VALUES
('T0000001', '서울', '제주', '제주 3박4일', '2026-07-01', '2026-07-04', 10, 30, 500000, 100000, 'N', 1),
('T0000002', '부산', '일본', '오사카 여행', '2026-08-10', '2026-08-13', 8, 25, 800000, 200000, 'N', 2),
('T0000003', '서울', '유럽', '유럽 7일', '2026-09-01', '2026-09-07', 15, 40, 2000000, 500000, 'N', 3),
('T0000004', '대구', '베트남', '다낭 여행', '2026-07-15', '2026-07-18', 10, 35, 700000, 150000, 'N', 4),
('T0000005', '인천', '태국', '방콕 여행', '2026-10-01', '2026-10-05', 12, 30, 900000, 200000, 'N', 5);

-- reserve
INSERT INTO reserve (cus_id, tour_num, res_date, dep_yn, exp_yn) VALUES
('C001', 'T0000001', CURRENT_DATE, 'N', 'N'),
('C002', 'T0000002', CURRENT_DATE, 'Y', 'N'),
('C003', 'T0000003', CURRENT_DATE, 'N', 'Y'),
('C004', 'T0000001', CURRENT_DATE, 'N', 'N'),
('C005', 'T0000004', CURRENT_DATE, 'Y', 'N');

--driver
insert into driver (driver_id, name, birthday, cell, pay, cont_date, cont_term) values
(1, '이수근', '750210', '010-7777-1111', 15000, '20240101', '12'),
(2, '유재석', '720814', '010-7777-2222', 16000, '20240201', '12'),
(3, '김해솔', '900303', '010-7777-3333', 15000, '20240301', '6'),
(4, '정형돈', '920404', '010-7777-4444', 17000, '20240115', '12'),
(5, '유영우', '880505', '010-7777-5555', 15000, '20240220', '12');

--tour_bus
INSERT INTO tour_bus (bus_id, seat, del_years) VALUES
(1, 45, 5),
(2, 30, 3),
(3, 25, 7),
(4, 40, 4),
(5, 50, 2);

--assign_driver
INSERT INTO assign_driver (tour_num, driver_id, work_hour) VALUES
('T0000001', 1, 8),
('T0000002', 2, 6),
('T0000003', 3, 10),
('T0000004', 4, 7),
('T0000005', 5, 9);

-- assign bus
INSERT INTO assign_bus (tour_num, bus_id) VALUES
('T0000001', 1),
('T0000002', 2),
('T0000003', 3),
('T0000004', 4),
('T0000005', 5);

-- 3. INDEX

-- TODO: CREATE INDEX

-- 운전기사 index
create INDEX driver_name_idx on driver(name);

-- 여행상품
create index tour_arrival_idx on tour(arrival);

-- 고객 이름 검색 인덱스
create index idx_customer_name ON customer(name);

--등급별 조회
CREATE INDEX idx_customer_ccode ON customer(c_code);

-- staff index : 직원 업무별
CREATE INDEX idx_staff_tcode ON staff(t_code);

-- tour 기간 검색
CREATE INDEX idx_tour_date ON tour(start_dt, end_dt);

-- 미 출발 고객조회 인덱스
CREATE INDEX idx_reserve_active 
ON reserve(cus_id) 
WHERE dep_yn = 'N';

--assign_bus index
CREATE INDEX idx_assign_driver_driver ON assign_driver(driver_id);


-- 4. TEST QUERIES

table customer; -- checking

-- Customer Grade Search
SELECT cus_id, name, c_code
FROM customer
WHERE c_code = 1;

table staff;
-- Employee Task Search
SELECT staff_id, name, t_code
FROM staff
where t_code = 1;

-- Tour Reservation Search
SELECT 
    c.name AS customer_name,
    t.tour_num,
    t.departure,
    t.arrival,
    r.res_date,
    r.dep_yn,
    r.exp_yn
FROM reserve r
JOIN customer c ON r.cus_id = c.cus_id
JOIN tour t ON r.tour_num = t.tour_num
WHERE r.dep_yn = 'N';

-- Assigned Driver Search
SELECT 
    t.tour_num,
    t.departure,
    t.arrival,
    d.name AS driver_name,
    ad.work_hour
FROM assign_driver ad
JOIN driver d ON ad.driver_id = d.driver_id
JOIN tour t ON ad.tour_num = t.tour_num;

-- INSERT example
-- 신규 고객 등록
INSERT INTO customer (cus_id, name, cell, addr, c_code)
values ('C006','한지민','010-1234-5678','서울 송파구',3)

table customer;

-- UPDATE example
-- 직원 급여 수정
table staff; --checking

update staff
set salary = salary * 1.1 -- 급여 10% 인상, 좋겠다
where hire_date = '20180124' -- 18년 1월 24일 입사자

--고객 등급 상승
update customer
set c_code = 2 -- 등급 상승 before 3, 
where cus_id = 'C005';

-- 예약 상태 업데이트
UPDATE reserve
SET dep_yn = 'Y'
WHERE tour_num = 'T0000001';

-- DELETE example
-- 예약 정보 삭제
DELETE FROM reserve
WHERE cus_id = 'C005'
AND tour_num = 'T0000004';


-- 5. BONUS TABLES (Optional)

-- driver
CREATE TABLE driver(
	driver_id INTEGER PRIMARY KEY,
	name VARCHAR(20) NOT NULL,
	birthday CHAR(6) NOT NULL,
	cell CHAR(13) NOT NULL,
	pay INTEGER DEFAULT 15000,
	cont_date CHAR(8),
	cont_term CHAR(8) -- 월 단위 값을 가짐
);
-- tour_bus
CREATE TABLE tour_bus(
	bus_id INTEGER PRIMARY KEY,
	seat INTEGER,
	del_years INTEGER	
);
-- table tour_bus; -- for checking
-- assign_driver
CREATE TABLE assign_driver(
	tour_num CHAR(8) PRIMARY KEY,
	driver_id INTEGER,
	work_hour INTEGER,

	FOREIGN KEY (tour_num) REFERENCES tour(tour_num),
	FOREIGN KEY (driver_id) REFERENCES driver(driver_id)
);

-- assign_bus
CREATE TABLE assign_bus(
	tour_num CHAR(8) PRIMARY KEY,
	bus_id INTEGER,

	FOREIGN KEY (tour_num) REFERENCES tour(tour_num),
	FOREIGN KEY (bus_id) references tour_bus(bus_id) 
		on delete set null -- 버스가 없어지면 null이 되도록
);